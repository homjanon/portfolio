#!/bin/bash
# 推送日报 HTML 到 GitHub Pages
# 用法: bash push_to_github.sh <html文件路径>
set -e

# 沙箱环境 TLS 握手兼容
export GIT_SSL_NO_VERIFY=1

TOKEN="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"
REPO="homjanon/portfolio"
BRANCH="main"
URL="https://x-access-token:${TOKEN}@github.com/${REPO}.git"

FILE="$1"
if [ -z "$FILE" ] || [ ! -f "$FILE" ]; then
    echo "❌ 用法: bash push_to_github.sh <html文件路径>"
    exit 1
fi

TMPDIR=$(mktemp -d)
trap "rm -rf $TMPDIR" EXIT

echo "📥 克隆仓库..."
git clone --depth 1 --branch "$BRANCH" "$URL" "$TMPDIR" 2>&1 | tail -1

echo "📝 复制文件..."
cp "$FILE" "$TMPDIR/daily-report.html"

cd "$TMPDIR"
git config user.email "bot@daily-report.local"
git config user.name "DailyReport Bot"

if git diff --quiet; then
    echo "⚠️ 内容无变化，跳过推送"
    exit 0
fi

git add daily-report.html
git commit -m "📰 $(TZ='Asia/Shanghai' date '+%Y-%m-%d') 日报更新" 2>&1 | tail -1
git push origin "$BRANCH" 2>&1 | tail -2

echo ""
echo "✅ 已推送！访问链接："
echo "   https://homjanon.github.io/portfolio/daily-report.html"
