#!/usr/bin/env python3
import json, os, sys, subprocess

KB_ID   = "E9D0u0kqRjG9KG_a71xNFqcutcdXudDT7tN0Hf2VTlU="
FOLDER_ID = "folder_7478464235984977"  # 投资/日报
CLIENT_ID = "55627ed064265a05b8e6286c5c939c16"
API_KEY  = "9O0kb0za9U38KrKXZLwk+vQFgYywS3bHRcvzLbyDTxIkoe13aUWFCapGi9yqORg0VTQVzXdKaA=="
BASE_URL = "https://ima.qq.com"

def call_api(path, body):
    import urllib.request
    url = f"{BASE_URL}{path}"
    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={
        "ima-openapi-clientid": CLIENT_ID,
        "ima-openapi-apikey": API_KEY,
        "Content-Type": "application/json",
    })
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read())

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 push_to_ima.py <markdown_file>")
        sys.exit(1)
    filepath = sys.argv[1]
    if not os.path.exists(filepath):
        print(f"ERROR: file not found: {filepath}")
        sys.exit(1)
    filename = os.path.basename(filepath)
    file_size = os.path.getsize(filepath)
    print(f"Pushing: {filename} ({file_size} bytes)")

    try:
        r = call_api("/openapi/wiki/v1/check_repeated_names", {
            "params": [{"name": filename, "media_type": 7}],
            "knowledge_base_id": KB_ID, "folder_id": FOLDER_ID})
        if r["code"] == 0 and r["data"]["results"][0]["is_repeated"]:
            print("File already exists, skipping")
            return
    except Exception as e:
        print(f"Check duplicate warning: {e}")

    r = call_api("/openapi/wiki/v1/create_media", {
        "file_name": filename, "file_size": file_size,
        "content_type": "text/markdown",
        "knowledge_base_id": KB_ID, "file_ext": "md"})
    if r["code"] != 0:
        print(f"Create media failed: {r}")
        sys.exit(1)
    media_id = r["data"]["media_id"]
    cred = r["data"]["cos_credential"]
    print(f"Media ID: {media_id}")

    try:
        from qcloud_cos import CosConfig, CosS3Client
    except ImportError:
        subprocess.run(["sudo", "pip3", "install", "cos-python-sdk-v5", "-q", "--break-system-packages"], check=True)
        from qcloud_cos import CosConfig, CosS3Client
    config = CosConfig(Region=cred["region"], SecretId=cred["secret_id"],
                       SecretKey=cred["secret_key"], Token=cred["token"], Scheme="https")
    client = CosS3Client(config)
    client.put_object_from_local_file(Bucket=cred["bucket_name"],
        LocalFilePath=filepath, Key=cred["cos_key"], EnableMD5=False)
    print("COS upload done")

    r = call_api("/openapi/wiki/v1/add_knowledge", {
        "media_type": 7, "media_id": media_id, "title": filename,
        "knowledge_base_id": KB_ID, "folder_id": FOLDER_ID})
    if r["code"] != 0:
        print(f"Add knowledge failed: {r}")
        sys.exit(1)
    print("Done: synced to IMA")

if __name__ == "__main__":
    main()
